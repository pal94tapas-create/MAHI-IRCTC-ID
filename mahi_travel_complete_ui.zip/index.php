<?php ?>
<!doctype html><html><head>
<meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<link rel='stylesheet' href='assets/css/style.css'>
<title>Mahi Travel</title>
</head>
<body>
<div class='container'>
<header class='header'>
<div class='brand'>Mahi Travel</div>
<nav class='nav'>
<a href='index.php'>Home</a>
<a href='admin/login.php'>Admin</a>
<a href='register.php'>Register</a>
<a href='login.php'>Login</a>
</nav>
</header>
<div class='hero'><strong>Top travel packages — curated for you.</strong></div>
<section class='grid'>
<!-- Dynamic product cards go here -->
</section>
<footer class='footer'>© 2025 Mahi Travel</footer>
</div>
</body>
</html>
