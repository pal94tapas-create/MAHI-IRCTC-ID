<?php
require 'config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $phone = trim($_POST['phone'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    if(!$phone || !$pass){ echo 'Phone and password required'; exit; }
    $c = db_connect();
    $ph = $c->real_escape_string($phone);
    $r = $c->query("SELECT * FROM users WHERE phone='$ph' LIMIT 1");
    if(!$r || !$r->num_rows){ echo 'No user'; exit; }
    $u = $r->fetch_assoc();
    if(password_verify($pass, $u['password_hash'])){
        $_SESSION['user_id'] = $u['id'];
        header('Location: index.php'); exit;
    } else { echo 'Invalid credentials'; }
}
?>
<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Login</title>
<link rel='stylesheet' href='assets/css/style.css'></head><body>
<div class='container'><h2>Login</h2>
<form method='POST'>
<input name='phone' placeholder='Phone' required><br>
<input name='password' type='password' placeholder='Password' required><br>
<button class='btn' type='submit'>Login</button>
</form></div></body></html>