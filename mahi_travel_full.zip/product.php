<?php
require 'config.php';
$conn = db_connect();
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if(!$p){ header('Location:index.php'); exit; }
?>
<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title><?=htmlspecialchars($p['title'])?></title>
<link rel='stylesheet' href='assets/css/style.css'>
</head><body>
<div class='container'>
  <div class='card'>
    <img src='<?=htmlspecialchars($p['image']?:"assets/default.jpg")?>' style='max-width:100%;height:auto'>
    <h2><?=htmlspecialchars($p['title'])?></h2>
    <p><?=nl2br(htmlspecialchars($p['description']))?></p>
    <p><strong>Price: ₹<?=number_format($p['price'],2)?></strong></p>
    <form method='POST' action='payment.php'>
      <input type='hidden' name='product_id' value='<?=$p['id']?>'>
      <label>Your name</label><br><input name='name' required><br>
      <label>Phone</label><br><input name='phone' required><br>
      <button class='btn' type='submit'>Proceed to Payment</button>
    </form>
  </div>
</div>
</body></html>