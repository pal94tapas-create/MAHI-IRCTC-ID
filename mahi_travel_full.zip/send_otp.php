<?php
require 'config.php';
header('Content-Type: application/json');
$phone = trim($_POST['phone'] ?? '');
$purpose = trim($_POST['purpose'] ?? 'login');
if(!$phone){ echo json_encode(['ok'=>false,'msg'=>'Phone required']); exit; }
$otp = rand(100000,999999);
$otp_hash = password_hash($otp, PASSWORD_DEFAULT);
$expires = date('Y-m-d H:i:s', time() + 300);
$c = db_connect();
$stmt = $c->prepare("INSERT INTO otp_requests (phone, otp_hash, purpose, expires_at) VALUES (?,?,?,?)");
$stmt->bind_param('ssss',$phone,$otp_hash,$purpose,$expires);
$stmt->execute();
$provider = defined('OTP_MODE') ? OTP_MODE : 'manual';
$sent = false;
if($provider === 'fast2sms' && defined('FAST2SMS_API_KEY') && FAST2SMS_API_KEY !== 'YOUR_FAST2SMS_API_KEY_HERE'){
    $apiKey = FAST2SMS_API_KEY;
    $message = urlencode("Your Mahi Travel OTP is: $otp \nValid 5 minutes.");
    $route = 'v3';
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://www.fast2sms.com/$route/index.php?authorization=$apiKey&sender_id=FSTSMS&message=$message&language=english&route=qt&numbers=$phone",
      CURLOPT_RETURNTRANSFER => true,
    ));
    $resp = curl_exec($curl);
    curl_close($curl);
    $sent = true;
} elseif($provider === 'msg91' && defined('MSG91_AUTHKEY') && MSG91_AUTHKEY !== 'YOUR_MSG91_AUTHKEY_HERE'){
    $authkey = MSG91_AUTHKEY;
    $message = urlencode("Your Mahi Travel OTP is: $otp. Valid 5 minutes.");
    $sender = 'MTRAVL';
    $route = 4;
    $postData = array('authkey'=>$authkey, 'mobiles'=>$phone, 'message'=>$message, 'sender'=>$sender, 'route'=>$route);
    $url = "https://control.msg91.com/api/sendhttp.php";
    $ch = curl_init();
    curl_setopt_array($ch, array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $postData));
    $output = curl_exec($ch);
    curl_close($ch);
    $sent = true;
} else {
    $sent = false;
}
$show_otp = ($provider === 'manual');
echo json_encode(['ok'=>true,'provider'=>$provider,'sent'=>$sent,'show_otp'=>$show_otp,'otp'=> $show_otp ? $otp : null, 'msg'=>'OTP generated']);
?>