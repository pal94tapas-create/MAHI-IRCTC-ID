<?php
require 'config.php';
$conn = db_connect();
$res = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
?>
<!doctype html>
<html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Mahi Travel - Top Packages</title>
<link rel='stylesheet' href='assets/css/style.css'>
</head><body>
<div class='container'>
  <header class='header'>
    <div class='brand'>Mahi Travel</div>
    <nav class='nav'>
      <a href='index.php'>Home</a>
      <a href='admin/login.php'>Admin</a>
      <a href='register.php'>Register</a>
      <a href='login.php'>Login</a>
    </nav>
  </header>
  <div class='hero'><strong>Top travel packages — curated for you.</strong></div>
  <section class='grid'>
    <?php while($p = $res->fetch_assoc()): ?>
    <article class='card'>
      <img src='<?=htmlspecialchars($p['image']?:"assets/default.jpg")?>' alt='<?=htmlspecialchars($p['title'])?>'>
      <h3><?=htmlspecialchars($p['title'])?></h3>
      <p><?=htmlspecialchars(mb_strimwidth($p['description'],0,120,'...'))?></p>
      <div class='price'>₹<?=number_format($p['price'],2)?></div>
      <a class='btn' href='product.php?id=<?=$p['id']?>'>View / Book</a>
    </article>
    <?php endwhile; ?>
  </section>
  <footer class='footer'>© <?=date('Y')?> Mahi Travel</footer>
</div>
</body></html>