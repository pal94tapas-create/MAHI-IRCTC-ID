<?php
require 'config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    if(!$phone || !$pass){ echo 'Phone and password required'; exit; }
    $c = db_connect();
    $ph = $c->real_escape_string($phone);
    $r = $c->query("SELECT id FROM users WHERE phone='$ph' LIMIT 1");
    if($r && $r->num_rows){ echo 'User with this phone already exists'; exit; }
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $name_e = $c->real_escape_string($name);
    $c->query("INSERT INTO users (name, phone, password_hash) VALUES ('$name_e','$ph','$hash')");
    echo 'Registered. Please login.';
    exit;
}
?>
<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Register</title>
<link rel='stylesheet' href='assets/css/style.css'></head><body>
<div class='container'><h2>Register</h2>
<form method='POST'>
<input name='name' placeholder='Name'><br>
<input name='phone' placeholder='Phone' required><br>
<input name='password' type='password' placeholder='Password' required><br>
<button class='btn' type='submit'>Register</button>
</form></div></body></html>