<?php
// config.php - Mahi Travel Full System
session_start();

// Database - set your credentials
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','mahi_travel');

// Admin credentials - change immediately after install
define('ADMIN_USER','admin');
define('ADMIN_PASS','1234');

// UPI QR path (admin can upload PNG)
define('UPI_QR_PATH','assets/upi_qr/admin_qr.png');

// OTP mode: manual, fast2sms, msg91
define('OTP_MODE','manual'); // default manual - shows OTP in response (testing)
define('FAST2SMS_API_KEY','YOUR_FAST2SMS_API_KEY_HERE');
define('MSG91_AUTHKEY','YOUR_MSG91_AUTHKEY_HERE');

function db_connect(){
    $c = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
    if($c->connect_error) die('DB Conn Error: '.$c->connect_error);
    $c->set_charset('utf8mb4');
    return $c;
}

function set_setting($key,$value){
    $c = db_connect();
    $k = $c->real_escape_string($key);
    $v = $c->real_escape_string($value);
    $c->query("INSERT INTO settings (`key`,`value`) VALUES ('$k','$v') ON DUPLICATE KEY UPDATE `value`='$v'");
}
function get_setting($key){
    $c = db_connect();
    $k = $c->real_escape_string($key);
    $r = $c->query("SELECT `value` FROM settings WHERE `key`='$k' LIMIT 1");
    if($r && $r->num_rows){ $row = $r->fetch_assoc(); return $row['value']; }
    return null;
}
?>