<?php
require 'config.php';
$conn = db_connect();
if($_SERVER['REQUEST_METHOD']==='POST' && empty($_GET['action'])){
  $product_id = (int)($_POST['product_id'] ?? 0);
  $name = $conn->real_escape_string(trim($_POST['name'] ?? ''));
  $phone = $conn->real_escape_string(trim($_POST['phone'] ?? ''));
  $conn->query("INSERT INTO orders (product_id, customer_name, customer_phone) VALUES ($product_id,'$name','$phone')");
  $order_id = $conn->insert_id;
  $p = $conn->query("SELECT * FROM products WHERE id=$product_id")->fetch_assoc();
}
if(isset($_GET['action']) && $_GET['action']==='confirm' && $_SERVER['REQUEST_METHOD']==='POST'){
  $order_id = (int)($_POST['order_id'] ?? 0);
  $upi_id = $conn->real_escape_string(trim($_POST['upi_id'] ?? ''));
  $upi_txn = $conn->real_escape_string(trim($_POST['upi_txn'] ?? ''));
  $conn->query("UPDATE orders SET upi_id='$upi_id', upi_txn_id='$upi_txn', status='paid' WHERE id=$order_id");
  echo "<p>UPI details submitted. Admin will verify and update status.</p><p><a href='index.php'>Back to Home</a></p>";
  exit;
}
?>
<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Payment</title>
<link rel='stylesheet' href='assets/css/style.css'>
</head><body>
<div class='container'>
  <div class='card'>
    <h2>Payment for <?=htmlspecialchars($p['title'] ?? 'Order')?></h2>
    <p>Amount: ₹<?=number_format($p['price'] ?? 0,2)?></p>
    <form method='POST' action='payment.php?action=confirm'>
      <input type='hidden' name='order_id' value='<?=htmlspecialchars($order_id ?? '')?>'>
      <label>Enter your UPI ID (eg: 9876543210@upi)</label><br><input name='upi_id' required><br>
      <label>UPI Txn ID (Optional)</label><br><input name='upi_txn'><br>
      <button class='btn' type='submit'>Submit UPI Details</button>
    </form>
    <h3>Or scan QR</h3>
    <?php if(file_exists(UPI_QR_PATH)): ?>
      <img src='<?=UPI_QR_PATH?>' alt='UPI QR' style='max-width:260px'>
    <?php else: ?>
      <p>Admin not uploaded QR yet. Admin can upload image at <code><?=UPI_QR_PATH?></code></p>
    <?php endif; ?>
  </div>
</div>
</body></html>