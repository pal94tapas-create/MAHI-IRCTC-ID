<?php
require '../config.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }
$conn = db_connect();
$id = (int)($_GET['id'] ?? 0);
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title = $conn->real_escape_string($_POST['title']);
  $desc = $conn->real_escape_string($_POST['description']);
  $price = (float)$_POST['price'];
  $conn->query("UPDATE products SET title='$title', description='$desc', price=$price WHERE id=$id");
  header('Location: dashboard.php'); exit;
}
$p = $conn->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
?>
<form method="POST">
  <input name="title" required value="<?= htmlspecialchars($p['title']) ?>"><br>
  <textarea name="description"><?= htmlspecialchars($p['description']) ?></textarea><br>
  <input name="price" required value="<?= htmlspecialchars($p['price']) ?>"><br>
  <button>Save</button>
</form>