<?php
require '../config.php';
if(isset($_POST['user'])){
  $u = $_POST['user']; $p = $_POST['pass'];
  if($u === ADMIN_USER && $p === ADMIN_PASS){
    $_SESSION['admin'] = true;
    header('Location: dashboard.php'); exit;
  } else {
    $err = 'Invalid credentials';
  }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Admin Login</title></head>
<body>
  <h1>Admin Login</h1>
  <?php if(!empty($err)) echo '<p style="color:red">'.htmlspecialchars($err).'</p>'; ?>
  <form method="POST">
    <input name="user" placeholder="Admin user"><br>
    <input name="pass" type="password" placeholder="Password"><br>
    <button>Login</button>
  </form>
</body></html>