<?php
require '../config.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }
$id = (int)($_GET['id'] ?? 0);
$conn = db_connect();
$conn->query("UPDATE orders SET status='verified' WHERE id=$id");
header('Location: dashboard.php');
