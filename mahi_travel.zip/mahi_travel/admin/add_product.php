<?php
require '../config.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }
$conn = db_connect();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title = $conn->real_escape_string($_POST['title']);
  $desc = $conn->real_escape_string($_POST['description']);
  $price = (float)$_POST['price'];
  $img = '';
  if(!empty($_FILES['image']['tmp_name'])){
    $target = __DIR__.'/../assets/uploads/';
    if(!is_dir($target)) mkdir($target,0755,true);
    $fn = time().'_'.basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'],$target.$fn);
    $img = 'assets/uploads/'.$fn;
  }
  $conn->query("INSERT INTO products (title,description,price,image) VALUES ('$title','$desc',$price,'$img')");
  header('Location: dashboard.php'); exit;
}
?>
<form method="POST" enctype="multipart/form-data">
  <input name="title" required placeholder="Package title"><br>
  <textarea name="description"></textarea><br>
  <input name="price" required placeholder="Price"><br>
  <input type="file" name="image"><br>
  <button>Add</button>
</form>