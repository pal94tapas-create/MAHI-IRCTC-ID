<?php
require 'config.php';
$conn = db_connect();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if(!$p){ header('Location: index.php'); exit; }
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title><?=htmlspecialchars($p['title'])?></title></head>
<body>
  <h1><?=htmlspecialchars($p['title'])?></h1>
  <p><?=nl2br(htmlspecialchars($p['description']))?></p>
  <p><strong>Price: ₹<?=number_format($p['price'],2)?></strong></p>

  <form method="POST" action="payment.php">
    <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
    <label>Your name</label><br>
    <input name="name" required><br>
    <label>Phone</label><br>
    <input name="phone" required><br>
    <button type="submit">Proceed to Payment</button>
  </form>
</body>
</html>