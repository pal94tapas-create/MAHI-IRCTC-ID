<?php
require 'config.php';
$conn = db_connect();
$res = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Mahi Travel - Top Packages</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <header><h1>Mahi Travel - Top Packages</h1></header>
  <main>
    <div class="products">
      <?php while($p = $res->fetch_assoc()): ?>
        <article class="product">
          <img src="<?= htmlspecialchars($p['image'] ?: 'assets/default.jpg') ?>" alt="<?= htmlspecialchars($p['title']) ?>" />
          <h2><?= htmlspecialchars($p['title']) ?></h2>
          <p><?= nl2br(htmlspecialchars($p['description'])) ?></p>
          <p><strong>Price: ₹<?= number_format($p['price'],2) ?></strong></p>
          <a href="product.php?id=<?= $p['id'] ?>">View / Book</a>
        </article>
      <?php endwhile; ?>
    </div>
  </main>
</body>
</html>