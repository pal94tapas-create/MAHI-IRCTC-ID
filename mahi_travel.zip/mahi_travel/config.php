<?php
// config.php
session_start();

// Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mahi_travel');

// Admin credentials (change immediately)
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', '1234');

// UPI QR image folder (writable)
define('UPI_QR_DIR', __DIR__ . '/assets/upi_qr/');

function db_connect(){
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if($conn->connect_error) die('DB Conn Error: '.$conn->connect_error);
    $conn->set_charset('utf8mb4');
    return $conn;
}
?>