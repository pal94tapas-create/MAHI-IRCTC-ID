<?php
require 'config.php';
$conn = db_connect();

if($_SERVER['REQUEST_METHOD']==='POST' && empty($_GET['action'])){
  $product_id = (int)($_POST['product_id'] ?? 0);
  $name = trim($_POST['name']);
  $phone = trim($_POST['phone']);

  $stmt = $conn->prepare("INSERT INTO orders (product_id, customer_name, customer_phone) VALUES (?,?,?)");
  $stmt->bind_param('iss',$product_id, $name, $phone);
  $stmt->execute();
  $order_id = $stmt->insert_id;

  $p = $conn->query("SELECT * FROM products WHERE id=" . $product_id)->fetch_assoc();
}
if(isset($_GET['action']) && $_GET['action']==='confirm' && $_SERVER['REQUEST_METHOD']==='POST'){
  $order_id = (int)($_POST['order_id'] ?? 0);
  $upi_id = $conn->real_escape_string(trim($_POST['upi_id']));
  $upi_txn = $conn->real_escape_string(trim($_POST['upi_txn']));
  $conn->query("UPDATE orders SET upi_id='$upi_id', upi_txn_id='$upi_txn', status='paid' WHERE id=$order_id");
  echo '<p>UPI details saved. Admin will verify and update status.</p>';
  exit;
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Payment</title></head>
<body>
  <h1>Payment for <?= htmlspecialchars($p['title'] ?? 'Order') ?></h1>
  <p>Amount: ₹<?= number_format($p['price'] ?? 0,2) ?></p>

  <form method="POST" action="payment.php?action=confirm">
    <input type="hidden" name="order_id" value="<?= htmlspecialchars($order_id ?? '') ?>">
    <label>Enter UPI ID you paid from (eg: 9876543210@upi)</label><br>
    <input name="upi_id" required><br>
    <label>UPI Txn ID (from your UPI app)</label><br>
    <input name="upi_txn"><br>
    <button type="submit">Submit UPI Details</button>
  </form>

  <h3>Or scan UPI QR (open your UPI app)</h3>
  <?php
  $qr = 'assets/upi_qr/admin_qr.png';
  if(file_exists($qr)){
    echo '<img src="'.$qr.'" alt="UPI QR" style="max-width:240px">';
  } else {
    echo '<p>(QR not uploaded by admin yet — admin can upload assets/upi_qr/admin_qr.png)</p>';
  }
  ?>
</body></html>