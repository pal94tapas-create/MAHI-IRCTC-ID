Mahi Travel - PHP system
================================
1) Import db_schema.sql into MySQL (create DB and tables).
2) Edit config.php and set DB creds and ADMIN_PASS.
3) Upload to Apache/PHP server. Ensure assets/uploads and assets/upi_qr are writable.
4) Visit /mahi_travel/ to see site. Admin panel at /mahi_travel/admin/login.php (default admin:admin, pass:1234).
